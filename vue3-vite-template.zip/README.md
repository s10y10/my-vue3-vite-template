# Vue 3 + TypeScript + Vite + pinia + elment-plus + tailwindcss 模板

# 建议安装 vscode 插件

# 目录简单说明
