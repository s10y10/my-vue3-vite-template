//需要缓存的二级页面,通过路由的meta配置
<script setup lang="ts"></script>

<template></template>

<style></style>
