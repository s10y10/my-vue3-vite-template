//基础布局,包含面包屑等信息
<script setup lang="ts"></script>

<template></template>

<style></style>
