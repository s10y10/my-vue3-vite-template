//基础界面布局
<script setup lang="ts"></script>

<template></template>

<style></style>
