const useMainStore = defineStore('main', {
  state: () => {
    return {
      name: 'main'
    }
  }
})

export default useMainStore
